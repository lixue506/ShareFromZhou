var project = {
    version: '<%=pkg.version%>'
};
